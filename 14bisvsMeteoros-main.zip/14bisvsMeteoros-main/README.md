
# 14bis vs Meteoros

Jogo criado para o curso de linguagem LUA: do zero ao jogo, na plataforma Alura.


## Tech Stack

**Stack:** 
Linguagem de programação LUA,
Plataforma cruzada de código aberto (LÖVE)
